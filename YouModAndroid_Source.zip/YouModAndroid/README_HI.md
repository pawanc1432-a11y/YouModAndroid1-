# YouMod Android — शुरुआती Android प्रोजेक्ट

यह आपकी `.ipa` फाइल को कन्वर्ट करके नहीं बनाया गया है। IPA iPhone ऐप है; यह अलग से लिखा गया एक छोटा Android WebView प्रोजेक्ट है जो आधिकारिक YouTube मोबाइल वेबसाइट खोलता है।

## इसमें क्या है
- Android ऐप का नाम: YouMod Android
- आधिकारिक `m.youtube.com` वेबसाइट
- बैक बटन से पिछला पेज
- PiP बटन: Android का Picture-in-Picture मोड खोलने की कोशिश करता है (Android 8.0+)

## जरूरी सीमाएँ
- यह YouMod का असली Android पोर्ट नहीं है; बंद iOS सोर्स कोड/मॉड फीचर्स इसमें नहीं हैं।
- YouTube की वेबसाइट/नीतियों के कारण बैकग्राउंड ऑडियो या PiP में वीडियो चलना हर डिवाइस/स्थिति में समर्थित नहीं है। यह ऐप YouTube की पाबंदियाँ बायपास नहीं करता।

## केवल Android फोन से APK बनाने का तरीका (क्लाउड बिल्ड)
इस ZIP में `.github/workflows/android.yml` भी है। GitHub Actions से APK क्लाउड में बन सकती है; फोन में Android Studio लगाने की जरूरत नहीं।

1. ZIP को फोन के Downloads में डाउनलोड करके File Manager से Extract करें।
2. Chrome में GitHub खोलें और अकाउंट बनाएं/लॉगिन करें।
3. नया Public या Private repository बनाएं, नाम `YouModAndroid` रखें।
4. Extract किए हुए फोल्डर के अंदर की सभी फाइलें और `.github` फोल्डर सहित repo के root में अपलोड करें। ध्यान दें: `.github` छिपा हुआ हो सकता है; File Manager में “Show hidden files” चालू करें।
5. Upload/commit के बाद repo में **Actions** टैब खोलें। `Build Android APK` workflow चलेगा।
6. सफल होने पर workflow run खोलें, नीचे **Artifacts** में `YouModAndroid-debug-apk` डाउनलोड करें।
7. ZIP artifact को Extract करें। `app-debug.apk` खोलकर इंस्टॉल करें। Android पूछे तो Chrome/Files को “Install unknown apps” की अनुमति दें।

अगर GitHub मोबाइल वेबसाइट में पूरा folder upload करना मुश्किल हो, तो कंप्यूटर या किसी विश्वसनीय cloud Android build service की जरूरत पड़ सकती है। GitHub पर अनजान लोगों की APK या source code न चलाएं।

यह debug APK होगी, Play Store release नहीं। इस build के लिए signing key नहीं बनाई गई है।
